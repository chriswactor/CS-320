package main.java.com.taskmanagement.model;

import java.util.Date;
import java.util.UUID;
//UUID for generating unique identifiers.
public class Appointment {
	private final String appointmentId;
	private Date appointmentDate;
	private String description;
	public Appointment(Date appointmentDate, String description) {
		if (appointmentDate == null || appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Appointment date cannot be null or in the past.");
        }
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Description must not be null and must not exceed 50 characters.");
        }
        this.appointmentId = UUID.randomUUID().toString().substring(0, 10);       
        this.appointmentDate = appointmentDate;
        this.description = description;      
    }
    public String getAppointmentId() {
        return appointmentId;
    }
    public Date getAppointmentDate() {
        return appointmentDate;
    }
    public void setAppointmentDate(Date appointmentDate) {
    	if (appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Appointment date cannot be in the past.");
        }
        this.appointmentDate = appointmentDate;
    }
    public void setDescription(String description) {
    	if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Description must not exceed 50 characters.");
        }
        this.description = description;
    }
    public String getDescription() {
        return description;
    }
}
