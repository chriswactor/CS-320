package main.java.com.taskmanagement.model;

import java.util.UUID;

public class Task {
    private final String taskId;
    private String name;
    private String description;

    public Task(String taskId, String name, String description) {
    	this.taskId = UUID.randomUUID().toString().substring(0, 10); // Generates a unique ID and takes the first 10 characters        
        setName(name);
        setDescription(description);
    }
    public String getTaskId() {
        return taskId;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        if (name != null && name.length() <= 20) {
            this.name = name;
        } else {
            throw new IllegalArgumentException("Name must be 20 characters or less.");
        }
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        if (description != null && description.length() <= 50) {
            this.description = description;
        } else {
            throw new IllegalArgumentException("Description must be 50 characters or less.");
        }
    }

}