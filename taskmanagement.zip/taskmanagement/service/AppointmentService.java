package main.java.com.taskmanagement.service;

import java.util.HashMap;
import main.java.com.taskmanagement.model.Appointment;

public class AppointmentService {
    private HashMap<String, Appointment> appointments = new HashMap<>();
    public void addAppointment(Appointment appointment) {
        if (appointments.containsKey(appointment.getAppointmentId())) {
            throw new IllegalArgumentException("Appointment ID already exists.");
        }
        appointments.put(appointment.getAppointmentId(), appointment);
    }
    public boolean deleteAppointment(String id) {
        if (appointments.containsKey(id)) {
        	appointments.remove(id);
            return true; // return true if deletion is successful
        }
            return false; 
            // return false if deletion fails
    }
    public Appointment getAppointment(String appointmentId) {
    	Appointment retrieved = appointments.get(appointmentId);
        return retrieved;
    }
}

