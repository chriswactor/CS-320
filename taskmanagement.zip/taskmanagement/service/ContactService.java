package main.java.com.taskmanagement.service;

import main.java.com.taskmanagement.model.Contact;
import java.util.HashMap;
import java.util.Map;

public class ContactService {
    private Map<String, Contact> contacts = new HashMap<>();

    public void addContact(Contact contact) throws IllegalArgumentException {
        if (contacts.containsKey(contact.getContactId())) {
            throw new IllegalArgumentException("Contact ID already exists");
        }
        contacts.put(contact.getContactId(), contact);
    }
    public void deleteContact(String contactId) {
        if (!contacts.containsKey(contactId)) {
            throw new IllegalArgumentException("Contact ID does not exist");
        }
        contacts.remove(contactId);
    }
    public void updateContact(String contactId, String newFirstName, String newLastName, String newPhone, String newAddress) {
        Contact contact = contacts.get(contactId);
        if (contact == null) {
            throw new IllegalArgumentException("Contact not found");
        }
        contact.setFirstName(newFirstName);
        contact.setLastName(newLastName);
        contact.setPhone(newPhone);
        contact.setAddress(newAddress);
    }
    public Contact getContact(String contactId) {
        return contacts.get(contactId);
    }
}
