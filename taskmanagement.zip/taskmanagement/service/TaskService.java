package main.java.com.taskmanagement.service;

import main.java.com.taskmanagement.model.Task;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class TaskService {
    private Map<String, Task> tasks = new HashMap<>();

    public void addTask(Task task) {
        if (tasks.containsKey(task.getTaskId())) {
            throw new IllegalArgumentException("Task with ID " + task.getTaskId() + " already exists.");
        }
        tasks.put(task.getTaskId(), task);
    }
    public Task getTask(String taskId) {
        if (!tasks.containsKey(taskId)) {
            throw new IllegalArgumentException("Task with ID " + taskId + " does not exist.");
        }
        return tasks.get(taskId);
    }
    public void updateTask(String taskId, String newName, String newDescription) {
        Task task = getTask(taskId);
        task.setName(newName);
        task.setDescription(newDescription);
    }
    public void deleteTask(String taskId) {
        if (!tasks.containsKey(taskId)) {
            throw new IllegalArgumentException("Task with ID " + taskId + " does not exist.");
        }
        tasks.remove(taskId);
    }
    public Collection<Task> getAllTasks() {
        return tasks.values();
    }
}
