package main.java.com.taskmanagement.test;

import main.java.com.taskmanagement.model.Appointment;
import main.java.com.taskmanagement.service.AppointmentService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.Date;

public class AppointmentServiceTest {
    private AppointmentService service; 

    @BeforeEach
    void setUp() {
        service = new AppointmentService();
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        service.addAppointment(new Appointment(futureDate, "Initial Appointment"));
    }
    @Test
    void testAddDuplicateAppointment() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000); 
        // Future date
        Appointment newAppointment = new Appointment(futureDate, "Follow up"); 
        // Create appointment with unique ID       
        service.addAppointment(newAppointment); 
        assertThrows(IllegalArgumentException.class, () -> service.addAppointment(newAppointment));
    }
    @Test
    void testDeleteExistingAppointment() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000); 
        // Future date
        Appointment newAppointment = new Appointment(futureDate, "Checkup");
        service.addAppointment(newAppointment); 
        String generatedId = newAppointment.getAppointmentId(); 
        // Retrieve ID
        assertTrue(service.deleteAppointment(generatedId)); 
    }
    @Test
    void testDeleteNonExistingAppointment() {
        assertFalse(service.deleteAppointment("NONEXISTENT"));
    }
    @Test
    void testAddAndRetrieveAppointment() {
        AppointmentService service = new AppointmentService();
        Date futureDate = new Date(System.currentTimeMillis() + 1000 * 60 * 60 * 24); 
        // Adding one day to the time.
        Appointment appointment = new Appointment(futureDate, "Checkup");
        service.addAppointment(appointment); 
        // Add appointment
        Appointment retrievedAppointment = service.getAppointment(appointment.getAppointmentId());
        assertNotNull(retrievedAppointment, "Appointment should be retrievable");
        assertEquals(appointment.getAppointmentId(), retrievedAppointment.getAppointmentId(), "The retrieved ID should match the added ID.");
    }

}
