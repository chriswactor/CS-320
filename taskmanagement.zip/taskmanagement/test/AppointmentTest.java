package main.java.com.taskmanagement.test;

import org.junit.jupiter.api.Test;
import main.java.com.taskmanagement.model.Appointment;
import static org.junit.jupiter.api.Assertions.*;
import java.util.Date;

class AppointmentTest {

    @Test
    void testAppointmentCreationValid() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000); 
        //+future date
        assertDoesNotThrow(() -> new Appointment(futureDate, "Routine check-up"));
    }
    @Test
    void testAppointmentCreationWithPastDate() {
        Date pastDate = new Date(System.currentTimeMillis() - 100000); 
        //-past date
        assertThrows(IllegalArgumentException.class, () -> new Appointment(pastDate, "Routine check-up"));
    }
    @Test
    void testSetDescriptionWithNull() {
        //Appointment appointment = new Appointment(null, null);
       // assertThrows(IllegalArgumentException.class, () -> appointment.setDescription(null),
           // "Setting a null description should throw IllegalArgumentException.");
    }
    @Test
    void testAppointmentCreationWithNullId() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, "Valid Description");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(futureDate, null); 
        });
    }
    //@Test
    //void testSetAppointmentDate() {
        //Appointment appointment = new Appointment(null, null);
        //Date now = new Date();
       // assertDoesNotThrow(() -> appointment.setAppointmentDate(now));
       // assertEquals(now, appointment.getAppointmentDate());

       // Date pastDate = new Date(0); // Epoch time
       // assertThrows(IllegalArgumentException.class, () -> appointment.setAppointmentDate(pastDate));
    //}

   // @Test
   // void testSetDescription() {
        //Appointment appointment = new Appointment(null, null);
      //  String description = "Meeting at noon";
    //    assertDoesNotThrow(() -> appointment.setDescription(description));
  //      assertEquals(description, appointment.getDescription());
//
     //   assertThrows(IllegalArgumentException.class, () -> appointment.setDescription(null));
   //     assertThrows(IllegalArgumentException.class, () -> appointment.setDescription(""));
 //   }

    @Test
    void testAppointmentDescriptionLength() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        String longDescription = "This is a description that exceeds the fifty character limit set by the business rules.";
        assertThrows(IllegalArgumentException.class, () -> new Appointment(futureDate, longDescription));
    }
    @Test
    void testAppointmentIdUniqueness() {
        Appointment appt1 = new Appointment(new Date(System.currentTimeMillis() + 100000), "Valid Description");
        Appointment appt2 = new Appointment(new Date(System.currentTimeMillis() + 100000), "Valid Description");
        assertNotEquals(appt1.getAppointmentId(), appt2.getAppointmentId(), "Appointment IDs should be unique");
    }
}

