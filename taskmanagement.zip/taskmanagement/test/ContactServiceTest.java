package main.java.com.taskmanagement.test;

import main.java.com.taskmanagement.model.Contact;
import main.java.com.taskmanagement.service.ContactService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactServiceTest {
    private ContactService service;

    @BeforeEach
    void setUp() {
        service = new ContactService();
        //for testing
        Contact contact = new Contact("001", "John", "Doe", "1234567890", "123 Elm St");
        service.addContact(contact);
    }
    @Test
    void testAddContact() {
        assertThrows(IllegalArgumentException.class, () -> {
            Contact contact = new Contact("001", "Jane", "Doe", "2345678901", "234 Elm St");
            service.addContact(contact);
        });
    }
    @Test
    void testDeleteContact() {
        service.deleteContact("001");
        assertNull(service.getContact("001"), "Contact should be null after deletion");
    }
    @Test
    void testUpdateContact() {
        service.updateContact("001", "Jane", "Doe", "2345678901", "234 Elm St");
        Contact updated = service.getContact("001");
        assertNotNull(updated, "Contact should not be null after update");
        assertEquals("Jane", updated.getFirstName(), "First name should be updated to Jan");
        assertEquals("2345678901", updated.getPhone(), "Phone should be updated");
    }
    @Test
    void testContactNotFound() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.updateContact("999", "Test", "User", "0000000000", "404 Not Found St");
        }, "Should throw an exception if contact ID does not exist");
    }
}
