package main.java.com.taskmanagement.test;

import main.java.com.taskmanagement.model.Contact;
import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.AfterEach;
import static org.junit.jupiter.api.Assertions.*;

public class ContactTest {

    @Test
    void testContactCreation() {
        assertDoesNotThrow(() -> new Contact("ID12345", "John", "Doe", "1234567890", "123 Elm Street"));
        
        assertThrows(IllegalArgumentException.class, () -> new Contact(null, "John", "Doe", "1234567890", "123 Elm Street"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("12345678901", "John", "Doe", "1234567890", "123 Elm Street"));
    }
    @Test
    void testSetFirstName() {
        Contact contact = new Contact("ID12345", "John", "Doe", "1234567890", "123 Elm Street");
        assertDoesNotThrow(() -> contact.setFirstName("Jane"));
        
        assertThrows(IllegalArgumentException.class, () -> contact.setFirstName(null));
        assertThrows(IllegalArgumentException.class, () -> contact.setFirstName("Johnathan Madison"));
    }
    @Test
    void testSetLastName() {
        Contact contact = new Contact("ID12345", "John", "Doe", "1234567890", "123 Elm Street");
        assertDoesNotThrow(() -> contact.setLastName("Smith"));
        
        assertThrows(IllegalArgumentException.class, () -> contact.setLastName(null));
        assertThrows(IllegalArgumentException.class, () -> contact.setLastName("Alexander Hamilton"));
    }
    @Test
    void testSetPhone() {
        Contact contact = new Contact("ID12345", "John", "Doe", "1234567890", "123 Elm Street");
        assertDoesNotThrow(() -> contact.setPhone("0987654321"));
        
        assertThrows(IllegalArgumentException.class, () -> contact.setPhone(null));
        assertThrows(IllegalArgumentException.class, () -> contact.setPhone("1234"));
    }
    @Test
    void testSetAddress() {
        Contact contact = new Contact("ID12345", "John", "Doe", "1234567890", "123 Elm Street");
        assertDoesNotThrow(() -> contact.setAddress("456 Oak Lane"));
        
        assertThrows(IllegalArgumentException.class, () -> contact.setAddress(null));
        assertThrows(IllegalArgumentException.class, () -> contact.setAddress("1234567890123456789012345678901234567890")); // Exceeds 30 characters
    }
}
