package main.java.com.taskmanagement.test;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import main.java.com.taskmanagement.model.Task;
import main.java.com.taskmanagement.service.TaskService;

import static org.junit.jupiter.api.Assertions.*;
import java.util.UUID;
import java.util.List;
import java.util.ArrayList;

class TaskServiceTest {
	private TaskService service;

    @BeforeEach
    void setUp() {
        service = new TaskService();
    }
   // @Test
 //   void testAddTask() {
     //   assertDoesNotThrow(() -> service.addTask(new Task("T001", "Review", "Review the document.")));
   //     assertThrows(IllegalArgumentException.class, () -> service.addTask(new Task("T001", "Review", "Review the document."))); // Attempting to add duplicate ID
 //   }
  //  @Test
//    void testUpdateTaskSuccess() {
      //  String taskId = "task001";
    //    Task task = new Task(taskId, "Initial Task", "Description of initial task");
  //      service.addTask(task);
//
//        assertDoesNotThrow(() -> service.updateTask(taskId, "Updated Task", "Updated description"));
        //Task updatedTask = service.getTask(taskId);
      //  assertNotNull(updatedTask);
    //    assertEquals("Updated Task", updatedTask.getName());
  //      assertEquals("Updated description", updatedTask.getDescription());
//    }

    @Test
    void testUpdateTaskFailNonExistent() {
        String nonExistentId = "nonexistent";
        assertThrows(IllegalArgumentException.class, () -> service.updateTask(nonExistentId, "Any name", "Any description"));
    }
    @Test
    void testAddTaskWithMaxIDAndNameLength() {
        String maxId = "1234567890"; // Maximum ID length 10 characters
        String maxName = "abcdefghijklmnopqrst"; // Maximum name length 20 characters
        Task task = new Task(maxId, maxName, "Normal description");
        assertDoesNotThrow(() -> service.addTask(task),
            "Should not throw an exception for max length ID and name");
        assertNotNull(service.getTask(maxId),
            "Task with max ID and name should be successfully added and retrievable.");
    }
    @Test
    void stressTestAddRemoveTasks() {
        int numberOfTasks = 1000; // Number for tasks added then removed
        List<String> taskIds = new ArrayList<>();

        // Add tasks store IDs
        for (int i = 0; i < numberOfTasks; i++) {
            String taskId = generateUniqueID();
            Task task = new Task(taskId, "Stress Test Task", "Task created as part of stress testing.");
            assertDoesNotThrow(() -> service.addTask(task),
                "Should not throw an exception while adding tasks in a stress test");
            taskIds.add(taskId);
        }
        assertEquals(numberOfTasks, service.getAllTasks().size(),
            "All tasks should be added and count should match the number of iterations.");

        // Removes tasks using list IDs
        taskIds.forEach(id -> service.deleteTask(id));

        assertTrue(service.getAllTasks().isEmpty(),
            "All tasks should be removed after stress testing.");
    }
    // Utility method generate unique ID, each test task has unique identifier.
    private String generateUniqueID() {
        return UUID.randomUUID().toString().substring(0, 10);
    }
    @Test
    void testUpdateNonExistentTask() {
        assertThrows(IllegalArgumentException.class, () -> service.updateTask("nonexistent", "New Name", "New Description"),
            "Updating a non-existent task should throw IllegalArgumentException.");
    }

    @Test
    void testUpdateTaskWithNullValues() {
        String taskId = "validId";
        service.addTask(new Task(taskId, "Original Name", "Original Description"));
        assertThrows(IllegalArgumentException.class, () -> service.updateTask(taskId, null, "Some Description"),
            "Updating task with null name should throw IllegalArgumentException.");
        assertThrows(IllegalArgumentException.class, () -> service.updateTask(taskId, "Some Name", null),
            "Updating task with null description should throw IllegalArgumentException.");
    }
    @Test
    void testUpdateTask() {
        String taskId = "T002"; // Defining the task ID here
        String taskName = "Initial Task";
        String taskDesc = "Initial Task Description";
        Task task = new Task(taskId, taskName, taskDesc); // Creating task object

        service.addTask(task); // Adding task to the service
        assertDoesNotThrow(() -> service.updateTask(taskId, "Edit", "Edit the document."), "Should not throw when updating existing task");
        assertThrows(IllegalArgumentException.class, () -> service.updateTask("T999", "Edit", "Edit non-existing document."), "Should throw as task ID does not exist");
    }
    @Test
    void testDeleteTask() {
    	Task task = new Task("T003", "Submit", "Submit the document.");
        service.addTask(task);
        assertDoesNotThrow(() -> service.deleteTask("T003"));
        assertThrows(IllegalArgumentException.class, () -> service.deleteTask("T003")); 
    }
}
