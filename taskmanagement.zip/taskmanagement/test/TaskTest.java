package main.java.com.taskmanagement.test;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import main.java.com.taskmanagement.model.Task;

import static org.junit.jupiter.api.Assertions.*;

class TaskTest {

    @Test
    void testTaskCreationValid() {
        assertDoesNotThrow(() -> new Task("T001", "Review", "Review the document."));
    }
    @Test
    void testTaskCreationInvalidId() {
        assertThrows(IllegalArgumentException.class, () -> new Task(null, "Review", "Review the document."), "Passing null as Task ID should throw IllegalArgumentException.");
       // assertThrows(IllegalArgumentException.class, () -> new Task("", "Review", "Review the document."), "Passing an empty string as Task ID should throw IllegalArgumentException.");
        //assertThrows(IllegalArgumentException.class, () -> new Task("12345678901", "Review", "Review the document."), "Passing an overly long string as Task ID should throw IllegalArgumentException.");
        //assertThrows(IllegalArgumentException.class, () -> new Task("invalid$id", "Review", "Review the document."), "Passing a string with invalid characters as Task ID should throw IllegalArgumentException.");
    }

    // Example of a parameterized test
    @ParameterizedTest
    @ValueSource(strings = {"text1", "", "12345678901", "invalid$id"})
    void testTaskCreationInvalidIdParameterized(String input) {
        assertThrows(IllegalArgumentException.class, () -> new Task(input, "Review", "Review the document."));
    }

    @Test
    void testTaskCreationInvalidName() {
        assertThrows(IllegalArgumentException.class, () -> new Task("T001", null, "Review the document."));
        assertThrows(IllegalArgumentException.class, () -> new Task("T001", "This name is very much too long for the name field according to the specification.", "Review the document."));
    }
    @Test
    void testTaskCreationInvalidDescription() {
        assertThrows(IllegalArgumentException.class, () -> new Task("T001", "Review", null));
        assertThrows(IllegalArgumentException.class, () -> new Task("T001", "Review", "This description is significantly longer than fifty characters, which is the maximum size allowed by the description."));
    }
}

